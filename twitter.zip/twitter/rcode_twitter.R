
# Load data-visualization libraries
# Install required packages if not already installed
if (!require(ggthemes)) install.packages("ggthemes", dependencies=TRUE)
if (!require(stopwords)) install.packages("stopwords", dependencies=TRUE)

# Load data-preprocessing libraries
library(dplyr)
library(tidyr)

# Text processing libraries
library(tm)
library(SnowballC)
library(stopwords)

# Load data-visualization libraries
library(ggplot2)
library(ggthemes)

# Download stopwords
stop_words <- stopwords::stopwords("en")

# Initialize lemmatizer
lemmatizer <- function(word) {
  wordStem(word, language = "en")
}

# Set option to display all columns in a data frame
options(tibble.width = Inf)

getwd()
setwd("C:/Users/debaj/Desktop/twitter_task")

# Install required packages if not already installed
if (!require(textTinyR)) install.packages("textTinyR", dependencies=TRUE)
if (!require(tm)) install.packages("tm", dependencies=TRUE)
if (!require(SnowballC)) install.packages("SnowballC", dependencies=TRUE)
if (!require(caret)) install.packages("caret", dependencies=TRUE)
if (!require(randomForest)) install.packages("randomForest", dependencies=TRUE)

# Load text processing libraries
library(textTinyR)
library(tm)
library(SnowballC)
library(stopwords)

# Download stopwords
stop_words <- stopwords::stopwords("en")

# Initialize lemmatizer function (use Porter stemmer as a substitute)
lemmatizer <- function(word) {
  wordStem(word, language = "en")
}

# Example text data for demonstration
texts <- c("This is a sample text.", "Another sample text for demonstration.")

# Tokenize and lemmatize the text data
tokenized_texts <- sapply(texts, function(text) {
  words <- unlist(strsplit(text, "\\s+"))
  lemmatized_words <- sapply(words, lemmatizer)
  paste(lemmatized_words, collapse = " ")
})

# TF-IDF vectorization
tfidf_matrix <- textTinyR::Term_Doc_Matrix(tokenized_texts, vec_type = 'tfidf')

# Load machine learning libraries
library(caret)
library(randomForest)
# Install required package if not already installed
if (!require(readr)) install.packages("readr", dependencies=TRUE)

# Load data-preprocessing library
library(readr)

# Load training data
df_data <- read_csv('twitter_training.csv', col_names = FALSE)

# Display the first five rows
head(df_data, 5)
# Load validation data
df_valid <- read_csv('twitter_validation.csv', col_names = FALSE)

# Display the first few rows
head(df_valid, 5)
# Rename columns
colnames(df_data) <- c('Tweet_ID', 'Topic', 'Sentiment', 'Tweet')

# Display the first few rows
head(df_data)
# Assuming df_data is already loaded and contains your data frame
num_rows <- nrow(df_data)
print(num_rows)
# Rename columns
colnames(df_valid) <- c('Tweet_ID', 'Topic', 'Sentiment', 'Tweet')

# Display the first few rows
head(df_valid)
# Calculate sentiment counts
train_sentiment_counts <- df_data %>% count(Sentiment)
valid_sentiment_counts <- df_valid %>% count(Sentiment)

# Print the results
print("Training Data Sentiment Counts:")
print(train_sentiment_counts)

print("Validation Data Sentiment Counts:")
print(valid_sentiment_counts)
# Check for missing values
missing_counts <- df_data %>%
  summarise_all(~sum(is.na(.)))

# Print the results
print(missing_counts)
# Check for missing values
missing_counts <- colSums(is.na(df_valid))

# Print the results
print(missing_counts)
# Drop rows with NA values
df_data <- df_data %>% na.omit()

# Check percentage of missing data after dropping missing features
missing_percentages <- colSums(is.na(df_data)) / nrow(df_data) * 100

# Print the results
print(missing_percentages)
# Calculate sentiment counts for training data
train_sentiment_counts <- table(df_data$Sentiment)

# Calculate sentiment counts for validation data
valid_sentiment_counts <- table(df_valid$Sentiment)

# Print the results
print("Training Data Sentiment Counts:")
print(train_sentiment_counts)

print("Validation Data Sentiment Counts:")
print(valid_sentiment_counts)
# Check for duplicate rows
num_duplicates <- sum(duplicated(df_data))

# Print the number of duplicate rows
print(num_duplicates)
# Remove duplicate rows
df_data <- distinct(df_data)

# Print the first few rows to verify
head(df_data)
# Check for duplicate rows
num_duplicates <- sum(duplicated(df_data))

# Print the number of duplicate rows
print(num_duplicates)

# Get number of rows in df_data
num_rows <- nrow(df_data)

# Print the number of rows
print(num_rows)
# Calculate sentiment counts for training and validation data
train_sentiment_counts <- table(df_data$Sentiment)
valid_sentiment_counts <- table(df_valid$Sentiment)

# Convert sentiment counts to data frames for plotting
train_sentiment_df <- data.frame(sentiment = names(train_sentiment_counts), count = as.numeric(train_sentiment_counts))
valid_sentiment_df <- data.frame(sentiment = names(valid_sentiment_counts), count = as.numeric(valid_sentiment_counts))

# Plotting pie charts using ggplot2
# Training data pie chart
train_pie <- ggplot(train_sentiment_df, aes(x = "", y = count, fill = sentiment)) +
  geom_bar(stat = "identity", width = 1, color = "white") +
  coord_polar("y", start = 0) +
  labs(title = "Training Data Sentiment Distribution", fill = "Sentiment") +
  theme_void() +
  theme(legend.position = "right")

# Validation data pie chart
valid_pie <- ggplot(valid_sentiment_df, aes(x = "", y = count, fill = sentiment)) +
  geom_bar(stat = "identity", width = 1, color = "white") +
  coord_polar("y", start = 0) +
  labs(title = "Validation Data Sentiment Distribution", fill = "Sentiment") +
  theme_void() +
  theme(legend.position = "right")

# Displaying side by side
library(gridExtra)
grid.arrange(train_pie, valid_pie, ncol = 2)
# Calculate sentiment counts for training and validation data
train_sentiment_counts <- table(df_data$Sentiment)
valid_sentiment_counts <- table(df_valid$Sentiment)

# Convert sentiment counts to data frames for plotting
train_sentiment_df <- data.frame(sentiment = names(train_sentiment_counts), count = as.numeric(train_sentiment_counts))
valid_sentiment_df <- data.frame(sentiment = names(valid_sentiment_counts), count = as.numeric(valid_sentiment_counts))

# Plotting bar charts using ggplot2
# Training data bar chart
train_bar <- ggplot(train_sentiment_df, aes(x = sentiment, y = count, fill = sentiment)) +
  geom_bar(stat = "identity", color = "white") +
  geom_text(aes(label = count), vjust = -0.3, size = 5) +
  labs(title = "Training Data Sentiment Distribution", x = "Sentiment", y = "Count", fill = "Sentiment") +
  theme_minimal()

# Validation data bar chart
valid_bar <- ggplot(valid_sentiment_df, aes(x = sentiment, y = count, fill = sentiment)) +
  geom_bar(stat = "identity", color = "white") +
  geom_text(aes(label = count), vjust = -0.3, size = 5) +
  labs(title = "Validation Data Sentiment Distribution", x = "Sentiment", y = "Count", fill = "Sentiment") +
  theme_minimal()

# Displaying side by side
library(gridExtra)
grid.arrange(train_bar, valid_bar, ncol = 2)
# Columns of interest
cols <- c('Topic', 'Sentiment')

# Print distinct values and counts
for (col in cols) {
  cat(col, ":\n")
  print(table(df_data[[col]]))
  cat("\n")
}
# Calculate sentiment counts
sentiment_counts <- table(df_data$Sentiment)

# Convert sentiment counts to a data frame for plotting
sentiment_df <- data.frame(sentiment = names(sentiment_counts), count = as.numeric(sentiment_counts))

# Pie chart
pie_chart <- ggplot(sentiment_df, aes(x = "", y = count, fill = sentiment)) +
  geom_bar(stat = "identity", width = 1, color = "white") +
  coord_polar("y", start = 0) +
  labs(title = "Sentiment Distribution", fill = "Sentiment") +
  theme_minimal() +
  theme(legend.position = "right")

# Count plot (similar to bar chart)
count_plot <- ggplot(df_data, aes(x = factor(Sentiment, levels = sentiment_df$sentiment))) +
  geom_bar(fill = "skyblue") +
  labs(title = "Sentiment Distribution", x = "Sentiment", y = "Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Arrange plots side by side
grid.arrange(pie_chart, count_plot, ncol = 2)
# Define custom colors
colors <- c('red', 'green', 'blue', 'gray')

# Calculate sentiment counts
sentiment_counts <- table(df_data$Sentiment)

# Convert sentiment counts to a data frame for plotting
sentiment_df <- data.frame(sentiment = names(sentiment_counts), count = as.numeric(sentiment_counts))

# Pie chart with custom colors
pie_chart <- ggplot(sentiment_df, aes(x = "", y = count, fill = sentiment)) +
  geom_bar(stat = "identity", width = 1, color = "white") +
  coord_polar("y", start = 0) +
  labs(title = "Sentiment Distribution - Pie Chart") +
  theme_minimal() +
  scale_fill_manual(values = colors) +
  theme(legend.position = "none")

# Bar plot with custom colors and annotations
bar_plot <- ggplot(sentiment_df, aes(x = factor(sentiment, levels = sentiment_df$sentiment), y = count, fill = sentiment)) +
  geom_bar(stat = "identity", color = "white") +
  labs(title = "Sentiment Distribution - Bar Plot", x = "Sentiment", y = "Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_fill_manual(values = colors) +
  geom_text(aes(label = count), vjust = -0.3, size = 5)

# Arrange plots side by side
grid.arrange(pie_chart, bar_plot, ncol = 2)
# Calculate topic counts
topic_counts <- table(df_data$Topic)

# Convert topic counts to a data frame for plotting
topic_df <- data.frame(topic = names(topic_counts), count = as.numeric(topic_counts))

# Bar plot
bar_plot <- ggplot(topic_df, aes(x = factor(topic, levels = topic_df$topic), y = count)) +
  geom_bar(stat = "identity", fill = "skyblue", color = "black") +
  labs(title = "Distribution of Topics", x = "Topics", y = "Counts") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Display the plot
print(bar_plot)
# Create cross-tabulation table
count_table <- table(df_data$Topic, df_data$Sentiment)
library(reshape2)
# Convert table to data frame if not already in that format
count_df <- as.data.frame.matrix(count_table)

# Print the structure of count_df to see the column names
str(count_df)


# Iterate over each column (sentiment) in count_table
for (sentiment in colnames(count_table)) {
  
  # Find minimum and maximum values and corresponding topics
  min_topic <- rownames(count_table)[which.min(count_table[, sentiment])]
  max_topic <- rownames(count_table)[which.max(count_table[, sentiment])]
  min_val <- min(count_table[, sentiment])
  max_val <- max(count_table[, sentiment])
  
  # Print the results
  cat(paste("Sentiment '", sentiment, "':\n", sep = ""))
  cat(paste("  Minimum value '", min_val, "' at Topic '", min_topic, "'\n", sep = ""))
  cat(paste("  Maximum value '", max_val, "' at Topic '", max_topic, "'\n\n", sep = ""))
}

filter_non_string <- function(df, column) {
  # Remove rows with NA values in the specified column
  df <- df[!is.na(df[[column]]), ]
  
  # Convert non-string values to strings
  df[[column]] <- as.character(df[[column]])
  
  return(df)
}


normalize_text <- function(text) {
  return(tolower(text))
}


remove_html_tags <- function(text) {
  # Remove HTML tags using regex
  return(gsub("<.*?>", "", text))
}

remove_urls <- function(text) {
  # Remove URLs using regex
  return(gsub("http\\S+|www\\S+", "", text))
}

remove_numbers <- function(text) {
  # Exclude numerical digits using regex
  return(gsub("\\d+", "", text))
}

remove_punctuation <- function(text) {
  # Remove punctuation marks using regex
  return(gsub("[[:punct:]]", "", text))
}


# Install stringr package if not already installed
install.packages("stringr")

# Load stringr package
library(stringr)

# Define tokenize_text function
tokenize_text <- function(text) {
  # Split text into individual words or tokens
  tokens <- str_split(text, "\\s+")
  
  # Flatten the list of tokens
  tokens <- unlist(tokens)
  
  return(tokens)
}

# Install tm package if not already installed
install.packages("tm")

# Load tm package
library(tm)

# Define remove_stopwords function
remove_stopwords <- function(tokens) {
  # Define English stopwords
  stop_words <- stopwords("en")
  
  # Remove stopwords from tokens
  filtered_tokens <- tokens[!tokens %in% stop_words]
  
  return(filtered_tokens)
}


# Install textTinyR package if not already installed
install.packages("textTinyR")
library(textTinyR)

vectorize_data <- function(text_data) {
  # Join the tokenized text into strings
  text_data_strings <- lapply(text_data, function(tokens) paste(tokens, collapse = " "))
  
  # Initialize TfidfVectorizer
  tfidf_vectorizer <- textTinyR::vocabVector(text_data_strings, tfidf = TRUE)
  
  # Fit and transform the text data to generate TF-IDF vectors
  tfidf_vectors <- textTinyR::textVector(text_data_strings, tfidf_vectorizer)
  
  return(list(tfidf_vectors = tfidf_vectors, tfidf_vectorizer = tfidf_vectorizer))
}
# Load stringr package
library(stringr)



# Load required packages
library(stringr)
library(tm)
library(textTinyR)
install.packages("stringr")
library(stringr)


# Define preprocess_text function
preprocess_text <- function(df) {
  df <- filter_non_string(df, 'Tweet')
  df$Tweet <- sapply(df$Tweet, normalize_text)
  df$Tweet <- sapply(df$Tweet, remove_html_tags)
  df$Tweet <- sapply(df$Tweet, remove_urls)
  df$Tweet <- sapply(df$Tweet, remove_numbers)
  df$Tweet <- sapply(df$Tweet, remove_punctuation)
  df$Tweet <- sapply(df$Tweet, tokenize_text)
  df$Tweet <- lapply(df$Tweet, remove_stopwords)
  return(df)
}




